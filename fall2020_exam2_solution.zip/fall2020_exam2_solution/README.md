# Q4: Long Answer

You are given a file of data (named `“heroes.csv”`) for an adventure game with the following structure:

```csv
Perseus,weapon:sword,strength:14,health:10
Hercules,weapon:muscles,strength:24,health:8
Ariadne,weapon:thread,strength:10,health:20
Odysseus,weapon:wile,strength:12,health:9
```

And so on... with as many "heroes" as the file creator wants to include in the game.

In a file named **heroes.py**, please define the following functions:

- Write a function, **`get_hero_traits()`**, that reads this file (i.e. `“heroes.csv”`) and creates and returns a 
dictionary of heroes. The key for each entry will be the ***name*** of each hero (i.e. a string such as `Perseus`, 
`Hercules`, etc.), and the value of each entry will be ***another dictionary*** containing that hero’s traits. The type 
of each of the traits in the value dictionary are as follows:

| **Trait**  | **Type** |
|------------|----------|
| `weapon`   | `str`   |
| `strength` | `int`  |
| `health`   | `int`  |

- Write a second function, **`battle()`** that will accept three parameters: `hero_traits`, a dictionary of heroes 
similar to the one returned by the `get_hero_traits()` function, `hero1`, a string representing the name of a hero, and
`hero2`, a string representing the name of another hero. The `battle()` function uses the dictionary to first print out
the message **`Perseus using sword is battling Hercules using muscles...`** in the case that `“Perseus”` is passed as 
the parameter value for `hero1` and `”Hercules”` is passed as the parameter value for `hero2` in a `battle()` function
call. The function then compares the strength of the two heroes and prints a message as to who wins the battle (for 
example, `Hercules wins!`). Normally, the stronger hero wins. You should use a function from the `random` module such 
that, while the stronger hero usually wins, the weaker hero still wins occasionally. For example, Perseus is weaker 
than Hercules according to the sample traits, but occasionally (say, 1 times out of 10, or 1 times out of 100, etc), 
Perseus will pull an upset and win.

A couple of things to note here:
- You should **not** assume that the file `“heroes.csv”` will always exist. Your program must be able to account for 
this possibility and **return an empty dictionary** when the file does not exist.
- Think about how a coin toss can determine who wins a battle. In a coin toss, each hero would have a 50/50 chance of 
winning, since we are choosing between two outcomes (for example, 1 and 0). In our case, we would like the weaker hero to have some, much smaller chance of winning. How might we use the `random` module to give the weaker hero a 10% chance of winning (for example) rather than a 50/50 chance?
- You do not need to include any sample function calls to the functions that you define in your code. We will run our 
own tests.

The solution can be found [**here**](heroes.py). Note that the hero names and traits in [**heroes.csv**](heroes.csv)
are a bit different than in the midterm. Regardless, your code had to work for any file of the same format!