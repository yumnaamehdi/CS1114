"""
Midterm 2, Q4 Solution
Authors: Sebastian Romero Cruz and Darryl Reeves
CS-UY 1114, Fall 2020
New York University Tandon School of Engineering
"""

from pprint import pprint
from random import random, randrange

UPSET_PROBABILITY = 0.2


def get_hero_traits():
    """
    Reads file 'heroes.csv' and creates dictionary of hero traits of the format specified in file README.md

    :return: Dictionary of hero traits
    """
    hero_traits = {}

    try:
        file = open("heroes.csv")
    except FileNotFoundError:
        print("ERROR: File heroes.csv was not found. Returning empty dictionary.")
        return hero_traits

    for line in file:
        line = line.strip().split(',')

        hero_name = line[0]
        weapon_trait_name, weapon_trait_value = line[1].split(':')
        strength_trait_name, strength_trait_value = line[2].split(':')
        health_trait_name, health_trait_value = line[3].split(':')

        hero_traits[hero_name] = {
            weapon_trait_name: weapon_trait_value,
            strength_trait_name: int(strength_trait_value),
            health_trait_name: int(health_trait_value)
        }

    file.close()

    return hero_traits


def battle(hero_traits, hero1, hero2):
    """
    Determines winner between two heroes in hero_traits. Assumes that both heroes specified by hero1 and hero2 exist in
    hero_traits. Uses an upset probability of 20%.

    :param hero_traits: Dictionary of hero information
    :param hero1: String containing name of a hero
    :param hero2: String containing name of another hero
    :return: None.
    """
    battle_message = "{} using {} is battling {} using {}...".format(hero1, hero_traits[hero1]['weapon'],
                                                                     hero2, hero_traits[hero2]['weapon'])
    print(battle_message)

    hero1_strength = hero_traits[hero1]['strength']
    hero2_strength = hero_traits[hero2]['strength']

    win_message = "{} WINS"

    # There were many, many ways to pick the winner. This might be the most basic:
    if hero1_strength > hero2_strength:
        if random() < UPSET_PROBABILITY:
            print(win_message.format(hero2))
        else:
            print(win_message.format(hero1))
    else:
        if random() < UPSET_PROBABILITY:
            print(win_message.format(hero1))
        else:
            print(win_message.format(hero2))


def main():
    """
    Just some sample behavior. You did not have to include this in your submission.
    """
    hero_traits = get_hero_traits()
    pprint(hero_traits)

    number_of_tests = 20
    hero_names = ["John", "Paul", "George", "Ringo"]

    # Picking two random hero names to use in our tests.
    test_hero1 = hero_names[randrange(0, len(hero_names))]
    test_hero2 = hero_names[randrange(0, len(hero_names))]

    while test_hero1 == test_hero2:
        test_hero2 = hero_names[randrange(0, len(hero_names))]  # So that the same hero is not picked twice.

    print("\nRUNNING {} TESTS...".format(number_of_tests))
    for test_number in range(number_of_tests):
        print("\nTEST #{}: ".format(test_number + 1))
        battle(hero_traits, test_hero1, test_hero2)

# DO NOT WRITE CODE BELOW THIS LINE


if __name__ == '__main__':
    main()
